from django.apps import AppConfig


class ConfigurationsConfig(AppConfig):
    name = 'configurations'
